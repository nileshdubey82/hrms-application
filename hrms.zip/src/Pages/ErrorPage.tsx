import React from "react";

type Props = {};

function ErrorPage({}: Props) {
  return (
    <div className="flex justify-start align-middle">
      <img src="./src/assets/light/404.jpg" />
    </div>
  );
}

export default ErrorPage;

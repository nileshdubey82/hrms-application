import * as React from "react";
import { BarChart } from "@mui/x-charts/BarChart";

const uData = [70, 70, 30, 40, 50, 60, 70];
const pData = [10, 20, 80, 40, 50, 20, 70];
const nData = [10, 50, 30, 40, 90, 60, 10];
const xLabels = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];

export default function StackedBarChart() {
  return (
    <BarChart
  width={500}
  height={300}
  series={[
    { data: pData, label: "pv", id: "pvId", stack: "total" },
    { data: uData, label: "uv", id: "uvId", stack: "total" },
    { data: nData, label: "nv", id: "nvId", stack: "total" },
  ]}
  xAxis={[
    { data: xLabels, scaleType: "band", tickSize: 5, stroke: '5' } // Adjust tickSize here
  ]}
  colors={["#7152F3", "#FEB85B", "#F45B69"]}
  
/>

  );
}

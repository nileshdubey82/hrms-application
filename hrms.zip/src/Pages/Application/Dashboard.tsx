import { CgNotes } from "react-icons/cg";
import { BiCalendarCheck } from "react-icons/bi";
import { MdOutlineBusinessCenter } from "react-icons/md";
import { AiFillCaretDown, AiFillCaretUp } from "react-icons/ai";
import { FaUsers } from "react-icons/fa";
import React from "react";
import DemoDate from "./DemoDate";
import AttendanceChart from "./AttendanceChart";

interface Props {}

const Dashboard = (props: Props) => {
  return (
    <section className="pt-5 flex ">
      <div className="first-section   w-[60%] ">
        <div className="report  grid-cols-2 gap-4 grid px-5 ">
          <div className="data-div  bg-white rounded border border-slate-200">
            <div className="gap-3 flex items-center px-5 py-2">
              <button className="btn btn-square text-[#7152F3] text-xl">
                <FaUsers />
              </button>
              <span>Total Employee</span>
            </div>
            <div className="gap-3 flex items-center justify-between    px-5 py-2">
              <span className="font-bold text-2xl">560</span>
              <button className="bg-[#30BE821A] text-[#30BE82] text-sm flex w-15 ps-3 pe-3 pt-1 pb-1 items-center rounded">
                <AiFillCaretUp /> <span>12%</span>
              </button>
            </div>
            <div className="border-t border-slate-200 px-5 py-2 ">
              <span className="text-slate-300 font-thin text-[12px]">
                Update: July 16, 2023
              </span>
            </div>
          </div>
          <div className="data-div  bg-white rounded border border-slate-200">
            <div className="gap-3 flex items-center px-5 py-2">
              <button className="btn btn-square text-[#7152F3] text-xl">
                <MdOutlineBusinessCenter />
              </button>
              <span>Total Applicant</span>
            </div>
            <div className="gap-3 flex items-center justify-between px-5 py-2">
              <span className="font-bold text-2xl">1050</span>
              <button className="bg-[#30BE821A] text-[#30BE82] text-sm flex w-15 ps-3 pe-3 pt-1 pb-1 items-center rounded">
                <AiFillCaretUp /> <span>5%</span>
              </button>
            </div>
            <div className="border-t border-slate-200 px-5 py-2 ">
              <span className="text-slate-300 font-thin text-[12px]">
                Update: July 14, 2023
              </span>
            </div>
          </div>
          <div className="data-div  bg-white rounded border border-slate-200">
            <div className="gap-3 flex items-center px-5 py-2">
              <button className="btn btn-square text-[#7152F3] text-xl">
                <BiCalendarCheck />
              </button>
              <span>Today Attendance</span>
            </div>
            <div className="gap-3 flex items-center justify-between    px-5 py-2">
              <span className="font-bold text-2xl">1050</span>
              <button className="bg-[#F45B691A] text-[#F45B69] text-sm flex w-15 ps-3 pe-3 pt-1 pb-1 items-center rounded">
                <AiFillCaretDown /> <span>8%</span>
              </button>
            </div>
            <div className="border-t border-slate-200 px-5 py-2 ">
              <span className="text-slate-300 font-thin text-[12px]">
                Update: July 14, 2023
              </span>
            </div>
          </div>
          <div className="data-div  bg-white rounded border border-slate-200">
            <div className="gap-3 flex items-center px-5 py-2">
              <button className="btn btn-square text-[#7152F3] text-xl">
                <CgNotes />
              </button>
              <span>Total Projects</span>
            </div>
            <div className="gap-3 flex items-center justify-between  px-5 py-2">
              <span className="font-bold text-2xl">250</span>
              <button className="bg-[#30BE821A] text-[#30BE82] text-sm flex w-15 ps-3 pe-3 pt-1 pb-1 items-center rounded">
                <AiFillCaretDown /> <span>12%</span>
              </button>
            </div>
            <div className="border-t border-slate-200 px-5 py-2 ">
              <span className="text-slate-300 font-thin text-[12px]">
                Update: July 14, 2023
              </span>
            </div>
          </div>
        </div>

        <div className="charts-attendance flex justify-center">
          <AttendanceChart/>
        </div>
      </div>

      <div className="second-section rounded   w-[40%] border border-slate-300">
        <div className="gap-3 flex items-center px-5 py-2 justify-between">
          <span className="font-bold text-xl">My Schedule</span>
          <button className="btn btn-square text-[#7152F3] text-xl">
            <CgNotes />
          </button>
        </div>
        <div className="flex justify-center align-middle">
        <DemoDate/>
        </div>
      </div>
    </section>
  );
};

export default Dashboard;
